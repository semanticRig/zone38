// Human-written JavaScript samples — idiosyncratic style, varied patterns
// Representative of pre-2022 open source code textures

function debounce(fn, ms) {
  var t;
  return function() {
    var self = this, args = arguments;
    clearTimeout(t);
    t = setTimeout(function() { fn.apply(self, args); }, ms);
  };
}

// quick LRU, nothing fancy
function LRU(max) {
  this._max = max || 100;
  this._map = {};
  this._head = null;
  this._tail = null;
  this._size = 0;
}

LRU.prototype.get = function(k) {
  var n = this._map[k];
  if (n == null) return;
  if (n !== this._head) {
    if (n.prev) n.prev.next = n.next;
    if (n.next) n.next.prev = n.prev;
    if (n === this._tail) this._tail = n.prev;
    n.prev = null;
    n.next = this._head;
    this._head.prev = n;
    this._head = n;
  }
  return n.v;
};

LRU.prototype.set = function(k, v) {
  var n = this._map[k];
  if (n) { n.v = v; this.get(k); return; }
  n = { k: k, v: v, prev: null, next: this._head };
  if (this._head) this._head.prev = n;
  this._head = n;
  if (this._tail == null) this._tail = n;
  this._map[k] = n;
  this._size++;
  if (this._size > this._max) {
    var old = this._tail;
    this._tail = old.prev;
    if (this._tail) this._tail.next = null;
    delete this._map[old.k];
    this._size--;
  }
};

var EVT = {};
EVT.on = function(obj, evt, fn) {
  (obj.__evt = obj.__evt || {})[evt] = (obj.__evt[evt] || []).concat(fn);
};
EVT.off = function(obj, evt, fn) {
  var a = (obj.__evt || {})[evt];
  if (a) obj.__evt[evt] = a.filter(function(f){ return f !== fn; });
};
EVT.emit = function(obj, evt) {
  var a = (obj.__evt || {})[evt], args = [].slice.call(arguments, 2);
  if (a) for (var i = 0; i < a.length; i++) a[i].apply(obj, args);
};

function deepGet(obj, pth) {
  var parts = pth.split('.');
  var cur = obj;
  for (var i = 0; i < parts.length; i++) {
    if (cur == null) return undefined;
    cur = cur[parts[i]];
  }
  return cur;
}

function shuffleArray(arr) {
  for (var i = arr.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
  }
  return arr;
}

function toHex(buf) {
  var out = '';
  for (var i = 0; i < buf.length; i++) {
    var h = buf[i].toString(16);
    if (h.length < 2) out += '0';
    out += h;
  }
  return out;
}

function throttle(fn, limit) {
  var wait = false;
  return function() {
    if (wait) return;
    fn.apply(this, arguments);
    wait = true;
    setTimeout(function() { wait = false; }, limit);
  };
}
